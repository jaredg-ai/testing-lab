const { TestWatcher } = require("@jest/core");
const {
  greeting,
  returnTwo,
  add,
  subtract,
  multiply,
  divide,
} = require("./functions");

test("should return the number 2", () => {
  expect(returnTwo(2)).toEqual(2);
});

test("should return the ${name}", () => {
  expect(greeting("James")).toEqual("Hello, James.");
  expect(greeting("Jill")).toEqual("Hello, Jill.");
});

// test("should add the num1 and num2", () => {
//   expect(add(1, 2)).toEqual(3);
//   expect(add(5, 9)).toEqual(14);
// });

// test("should subtract the num1 and num2", () => {
//   expect(subtract(3, 1)).toEqual(2);
//   expect(subtract(4, 2)).toEqual(2);
// });

// test("should multiply the num1 and num2", () => {
//   expect(multiply(2, 2)).toEqual(4);
//   expect(multiply(5, 2)).toEqual(10);
// });

// test("should divide the num1 by the num2", () => {
//   expect(divide(4, 2)).toEqual(2);
//   expect(divide(10, 2)).toEqual(5);
// });


//this is a lot nicer 
const mathFunctions = {
  add,
  subtract,
  multiply,
  divide,
};

describe("mathFunctions", () => {
  test("should add the num1 and num2", () => {
    expect(add(1, 2)).toEqual(3);
    expect(add(5, 9)).toEqual(14);
  });
  test("should subtract num1 and num2", () => {
    expect(subtract(4, 2)).toEqual(2);
    expect(subtract(7, 5)).toEqual(2);
  });
  test("should multiply num1 and num2", () => {
    expect(multiply(2, 2)).toEqual(4);
    expect(multiply(5, 2)).toEqual(10);
  });
  test("should divide num1 and num2", () => {
    expect(divide(4, 2)).toEqual(2);
    expect(divide(10, 2)).toEqual(5);
  });
});
